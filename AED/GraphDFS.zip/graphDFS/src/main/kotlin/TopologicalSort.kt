
class TopologicalSort {
    val INFINITE = Int.MAX_VALUE
    enum class Color { WHITE, BLACK, GREY }
    var timeStamp = 0

    private class Vertex {
        constructor(i: Int, nm: String) {
            id = i
            name = nm
        }
        var id: Int
        var name: String
        var listOfAdjacent: Edge? = null

        var color = Color.WHITE
        var distance = 0
        var finish = 0
        var p: Vertex? = null
    }

    private class Edge {
        constructor(adj: Int) {
            adjacent = adj
        }
        var adjacent: Int
        var next: Edge? = null
        var previous: Edge? = null
    }

    constructor(dim: Int) {
        graph = arrayOfNulls(dim)
        size = dim
    }

    private val graph: Array<Vertex?>
    private var size: Int
    private val sortedList = mutableListOf<String>()

    fun addVertex(id: Int, nm: String): String? {
        if (graph[id] != null) return null
        val v = Vertex(id, nm)
        graph[id] = v
        return v.name
    }

    fun addEdge(id: Int, idAdj: Int): Int? {
        val v = graph[id]
        if (v == null) return null
        val edge = Edge(idAdj)
        edge.next = v.listOfAdjacent
        v.listOfAdjacent?.let {vl -> vl.previous = edge}
        v.listOfAdjacent = edge
        return idAdj
    }

    fun getTopologicalSort(): MutableList<String> {
        return sortedList.asReversed()
    }

    fun show() {  // mostra o grafo na forma de listas adjacentes
        for (i in graph.indices) {
            if (graph[i] != null) {
                var head = graph[i]?.listOfAdjacent
                print("${graph[i]!!.name} -> ")
                while (head != null) {
                    print("${graph[head.adjacent]!!.name} ")
                    head = head.next
                }
                println()
            }
        }
    }

    fun DFS() {
        for (i in graph.indices) {
            if (graph[i] != null) {
                val u = graph[i]
                if (u != null) {
                    u.color = Color.WHITE
                    u.p = null
                }
            }
        }
        timeStamp = 0
        for (i in graph.indices) {
            if (graph[i] != null ) {
                val u = graph[i]
                if (u != null && u.color == Color.WHITE) DFSVisit(u)
            }
        }
    }
    private fun DFSVisit(u: Vertex) {
        timeStamp++
        u.distance = timeStamp
        u.color = Color.GREY
        var edges = u.listOfAdjacent
        while (edges != null) {
            val v = graph[edges.adjacent]
            if (v != null && v.color == Color.WHITE) {
                v.p = u
                DFSVisit(v)
            }
            edges = edges.next
        }
        u.color = Color.BLACK
        timeStamp++
        u.finish = timeStamp
        sortedList.add(u.name)
        println("${u.name} ${u.distance}/${u.finish}")
    }
}
