
fun main() {
    val diGraph = TopologicalSort(10)

    diGraph.addVertex(1, "shirt");  diGraph.addVertex(2, "tie"); diGraph.addVertex(3, "jacket")
    diGraph.addVertex(4, "belt");  diGraph.addVertex(5, "watch"); diGraph.addVertex(6, "undershorts")
    diGraph.addVertex(7, "pants");  diGraph.addVertex(8, "shoes"); diGraph.addVertex(9, "socks")
    diGraph.addEdge(1, 4); diGraph.addEdge(1, 2)
    diGraph.addEdge(2, 3)
    diGraph.addEdge(4, 3)
    diGraph.addEdge(6, 8); diGraph.addEdge(6, 7)
    diGraph.addEdge(7, 8); diGraph.addEdge(7, 4)
    diGraph.addEdge(9, 8)

    println("===========================")
    println("Graph:")
    println("---------------------------")
    diGraph.show()
    println("===========================")
    println("Depth First Search:")
    println("---------------------------")
    diGraph.DFS()
    println("===========================")
    println("Topological Sort:")
    println("---------------------------")
    println(diGraph.getTopologicalSort())
    println("===========================")
}