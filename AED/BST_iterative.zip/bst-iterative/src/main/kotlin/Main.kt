
fun main() {
    val cmp: (Int, Int) -> Int = { i1: Int, i2: Int -> i1 - i2 }

    var tree = createBST(cmp)
    print("Breadth First Search: "); visitByLevels(tree); println()
    println("Search (5): " + search(tree, 5, cmp)!!.value)
    println("Maximum: " + maximum(tree)!!.value)
    var x = minimum(tree)
    var y = successor(x)
    if (x != null && y != null) {
        println("Minimum: " + x.value)
        println("Successor: " + y.value)
        println("Remove: " + x.value); tree = remove(tree, x)
    }
    print("Breadth First Search: "); visitByLevels(tree)
    println()
}

fun createBST(cmp: Comparator<Int>): Node<Int>? {
    var tree: Node<Int>? = null
    var node: Node<Int>
    node = Node(9, null,null, null); tree = add(tree, node, cmp)
    node = Node(4, null,null, null); tree = add(tree, node, cmp)
    node = Node(1, null,null, null); tree = add(tree, node, cmp)
    node = Node(8, null,null, null); tree = add(tree, node, cmp)
    node = Node(5, null,null, null); tree = add(tree, node, cmp)
    node = Node(6, null,null, null); tree = add(tree, node, cmp)
    node = Node(7, null,null, null); tree = add(tree, node, cmp)
    return tree
}
