data class Node<E>(var value: E, var p: Node<E>?, var left: Node<E>?, var right:Node<E>?)

fun <E> minimum(root: Node<E>?): Node<E>? {
    var x = root
    while (x != null && x.left != null) x = x.left
    return x
}

fun <E> maximum(root: Node<E>?): Node<E>? {
    var x = root
    while (x != null && x.right != null) x = x.right
    return x
}

fun <E> successor(x: Node<E>?): Node<E>? {
    var x = x
    var y: Node<E>? = null
    if (x != null && x.right != null) return minimum(x.right)
    if (x != null) y = x.p
    while (y != null && x == y.right) {
        x = y
        y = y.p
    }
    return y
}

fun <E> search(root: Node<E>?, key: E, cmp: Comparator<E>): Node<E>? {
    var x = root
    while (x != null && cmp.compare(key, x.value) != 0)
        x = if (cmp.compare(key, x.value) < 0) x.left else x.right
    return x
}

fun <E> add(root: Node<E>?, z: Node<E>, cmp: Comparator<E>): Node<E>? {
    var root = root
    var y: Node<E>? = null
    var x = root
    while (x != null) {
        y = x
        x = if (cmp.compare(z.value, x.value) <= 0) x.left else x.right
    }
    z.p = y
    if (y == null) root = z // tree was empty
    else if (cmp.compare(z.value, y.value) <= 0) y.left = z
    else y.right = z
    return root
}

fun <E> remove(root: Node<E>?, z: Node<E>): Node<E>? {
    var root = root
    var y: Node<E>? = null
    if (z.left == null) root = transplant(root, z, z.right)
    else
        if (z.right == null) root = transplant(root, z, z.left)
        else {
            val y = minimum(z.right)
            if (y != null && y.p !== z) {
                root = transplant(root, y, y.right)
                y.right = z.right
                y.right?.let {yR -> yR.p = y}
            }
            root = transplant(root, z, y)
            y?.left = z.left
            if (y != null) y.left?.let { yL -> yL.p = y }
        }
    return root
}

private fun <E> transplant(root: Node<E>?, u: Node<E>?, v: Node<E>?): Node<E>? {
    var root = root
    if (u != null) {
        if (u.p == null) root = v
        else
            u.p?.let { uP ->
                if (u == uP.left) uP.left = v
                else uP.right = v
            }
        if (v != null) v.p = u.p
    }
    return root
}

fun <E> visitByLevels(root: Node<E>?) {
    var root = root
    val list = Queue<Node<E>>(10)
    if (root != null) {
        list.enqueue(root)
        while (!list.isEmpty()) {
            root = list.dequeue()
            print(root.value.toString() + " ")
            if (root.left != null) root.left?.let { rL ->  list.enqueue(rL) }
            if (root.right != null) root.right?.let { rR -> list.enqueue(rR) }
        }
    }
}