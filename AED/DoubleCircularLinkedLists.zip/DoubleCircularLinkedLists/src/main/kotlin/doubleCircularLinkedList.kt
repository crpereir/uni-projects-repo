// Double Linked Lists With Sentinel, Circular

class Node<E> {
    var value: E
    var previous: Node<E>
    var next: Node<E>
    constructor() {
        value = Any() as E
        previous = this
        next = this
    }
    constructor(data: E) {
        value = data
        previous = this
        next = this
    }
}

fun main() {
    val dummy = Node<String>()

    add(dummy, "Tania")
    add(dummy, "Ricardo")
    add(dummy, "Manuel")
    add(dummy, "Cristina")
    add(dummy, "Ana")
    showList(dummy)
    showListReverse(dummy)

    println("remove Manuel:")
    remove(dummy, "Manuel") {s1: String, s2: String -> s1.compareTo(s2)}
    showList(dummy)
    val res = contains(dummy, "Manuel") {s1: String, s2: String -> s1.compareTo(s2)}
    println("contains Manuel: $res")
    println("size: ${size(dummy)}")
    println("get idx 1: ${get(dummy, 1)}")
}

// calcula a dimensão da lista
fun <E> size(head: Node<E>): Int {
    var x = head.next
    var count = 0
    while (x != head) {
        count++
        x = x.next
    }
    return count
}

// verifica se o item com chave k existe na lista
fun <E> contains(head: Node<E>, k: E, cmp: Comparator<E>): Boolean {
    head.value = k
    var x = head.next
    while (cmp.compare(k, x.value) != 0) x = x.next
    return x != head
}

// devolve o elemento da lista na posição idx
fun <E> get(head: Node<E>, idx: Int): E? {
    if (idx >= size(head)) return null
    var x = head.next
    var count = 0
    while (x != head) {
        if (count == idx) return x.value
        count++
        x = x.next
    }
    return null
}

// insere um novo elemento na primeira posição da lista
fun <E> add(head: Node<E>, newItem: E) {
    val x = Node(newItem)
    x.next = head.next
    head.next.previous = x
    head.next = x
    x.previous = head
}

// remove o elemento da lista com chave k
fun <E> remove(head: Node<E>, k: E, cmp:Comparator<E>) {
    var x = head.next
    while (x != head) {
        if (cmp.compare(k, x.value) == 0) {
            x.previous.next= x.next
            x.next.previous = x.previous
            break
        }
        else x = x.next
    }
}

// mostra a lista
fun <E> showList(head: Node<E>) {
    print("List = ")
    var x = head.next
    while (x != head) {
        print("${x.value}  ")
        x = x.next
    }
    println()
}

fun <E> showListReverse(head: Node<E>) {
    print("List reverse = ")
    var x = head.previous
    while (x != head) {
        print("${x.value}  ")
        x = x.previous
    }
    println()
}

