
class Graph {
    val INFINITE = Int.MAX_VALUE
    enum class Color { WHITE, BLACK, GREY }

    private class Vertex {
        constructor(i: Int, nm: String) {
            id = i
            name = nm
        }
        var id: Int
        var name: String
        var listOfAdjacent: Edge? = null

        var color = Color.WHITE
        var distance = 0
        var p: Vertex? = null
    }

    private class Edge {
        constructor(adj: Int) {
            adjacent = adj
        }
        var adjacent: Int
        var next: Edge? = null
        var previous: Edge? = null
    }

    constructor(dim: Int) {
        graph = arrayOfNulls(dim)
        size = dim
    }

    private var graph: Array<Vertex?>
    private var size: Int

    fun addVertex(id: Int, nm: String): String? {
        if (graph[id] != null) return null
        val v = Vertex(id, nm)
        graph[id] = v
        return v.name
    }

    fun addEdge(id: Int, idAdj: Int): Int? {
        val v = graph[id]
        if (v == null) return null
        val edge = Edge(idAdj)
        edge.next = v.listOfAdjacent
        v.listOfAdjacent?.let {vl -> vl.previous = edge}
        v.listOfAdjacent = edge
        return idAdj
    }

    fun show() {  // mostra o grafo na forma de listas adjacentes
        for (i in graph.indices) {
            if (graph[i] != null) {
                var head = graph[i]?.listOfAdjacent
                print("$i -> ")
                while (head != null) {
                    print("${head.adjacent} ")
                    head = head.next
                }
                println()
            }
        }
    }

    fun BFS(vInit: Int) {
        for (i in graph.indices) {
            if (graph[i] != null) {
                val u = graph[i]
                if (u != null) {
                    u.color = Color.WHITE
                    u.distance = INFINITE
                    u.p = null
                }
            }
        }
        val s = graph[vInit] // nó inicial
        if (s != null) {
            s.color = Color.GREY
            s.distance = 0
            s.p = null
        }
        val q: Queue<Vertex?> = Queue(size)
        q.enqueue(s)
        while (!q.isEmpty()) {
            val u = q.dequeue()
            if (u != null) {
                println("${u.name} d(${u.distance}) ")
                var edges = u.listOfAdjacent
                while (edges != null) {
                    val v = graph[edges.adjacent]
                    if (v != null && v.color == Color.WHITE) {
                        v.color = Color.GREY
                        v.distance = u.distance + 1
                        v.p = u
                        q.enqueue(v)
                    }
                    edges = edges.next
                }
                u.color = Color.BLACK
            }
        }
    }
}