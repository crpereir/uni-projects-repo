
fun main() {
    val hashT: Table<String> = HashTable<String>()
    println("IsEmpty = ${hashT.isEmpty()}")
    hashT.add("Carol")
    hashT.add("João")
    hashT.add("Ermelinda")
    hashT.add("Esteves")
    hashT.add("Ana")
    println("Size = ${hashT.size}")
    println("Contains(Ermelinda) = ${hashT.contains("Ermelinda")}")
    println("Remove(Ermelinda) = ${hashT.remove("Ermelinda")}")
    println("Contains(Ermelinda) = ${hashT.contains("Ermelinda")}")
}
