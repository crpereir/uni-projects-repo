interface Table<E> {
    val size: Int
    fun isEmpty(): Boolean
    fun contains(element: E): Boolean
    fun add(element: E): Boolean
    fun remove(element: E): Boolean
}