class HashTable<E>: Table<E> {

    private class Node<E>(e: E) {
        var element: E = e
        var next: Node<E>? = null
        var previous: Node<E>? = null

    }

    private var table: Array<Node<E>?>
    private var dimTable = 0 // M dimensão da tabela
    override var size = 0    // N chaves

    constructor() {
        table = arrayOfNulls<Node<E>?>(10)
        dimTable = 10
    }

    constructor(dim: Int) {
        table = arrayOfNulls<Node<E>?>(dim)
        dimTable = dim
    }

    private fun hash(e: E): Int {
        var idx = (e.hashCode() % dimTable)
        return if (idx < 0) idx + dimTable else idx
    }

    override fun isEmpty() = size == 0

    override fun contains(element: E): Boolean {
        val idx = hash(element)
        var curr = table[idx]
        while (curr != null) {
            if (element != null && element.equals(curr.element)) return true
            curr = curr.next
        }
        return false
    }

    override fun add(element: E): Boolean {
        if (contains(element)) return false
        val idx = hash(element)
        val node = Node(element)
        node.next = table[idx]
        if (table[idx] != null) table[idx]?.previous = node
        table[idx] = node
        size++
        return true
    }

    override fun remove(element: E): Boolean {
        val idx = hash(element)
        var curr = table[idx]
        while (curr != null) {
            if (element != null && element.equals(curr.element)) {
                val node = curr
                if (node.previous != null) node.previous!!.next = node.next
                else table[idx] = node.next
                if (node.next != null) node.next!!.previous = node.previous
                size--
                return true
            }
            else curr = curr.next
        }
        return false
    }
}