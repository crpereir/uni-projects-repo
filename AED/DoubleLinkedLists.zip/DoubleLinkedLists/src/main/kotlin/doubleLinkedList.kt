// Double Linked Lists Without Sentinel, Non-circular

data class Node<E>(var value: E, var next: Node<E>?, var previous:Node<E>?)

fun main() {
    var list: Node<Int>? = null
    list = add(list, 1)
    list = add(list, 4)
    list = add(list, 16)
    list = add(list, 9)
    list = add(list, 25)
    showList(list)
    println("remove 25:")
    list = remove(list, 25) {n1: Int, n2: Int -> n1 - n2}
    showList(list)
    val res = contains(list, 4) {n1: Int, n2: Int -> n1 - n2}
    println("contains 4: $res")
}

// verifica se o item com chave k existe na lista
fun <E> contains(head: Node<E>?, k: E, cmp:Comparator<E>): Boolean {
    var x = head
    while (x != null) {
        if (cmp.compare(k, x.value) == 0) return true
        x = x.next
    }
    return false
}

// insere um novo elemento na primeira posição da lista
fun <E> add(head: Node<E>?, newItem: E): Node<E>? {
    var head = head
    var x = Node(newItem, null, null)
    x.next = head
    if (head != null) head.previous = x
    head = x
    x.previous = null
    return head
}

// remove o elemento da lista com chave k
fun <E> remove(head: Node<E>?, k: E, cmp:Comparator<E>): Node<E>? {
    var head = head
    var x = head
    while (x != null) {
        if (cmp.compare(k, x.value) == 0) {
            if (x.previous == null) head = x.next
            else {
                //x.previous!!.next = x.next
                x.previous?.let { xPrev ->
                    x?.let { xCurr -> xPrev.next = xCurr.next }
                }
            }
            //x.next!!.previous = x.previous
            x.next?.let { xNext ->
                x?.let { xCurr -> xNext.previous = xCurr.previous }
            }
            return head
        }
        else x = x.next
    }
    return head
}

// mostra a lista
fun <E> showList(head: Node<E>?) {
    print("List: ")
    var x = head
    while (x != null) {
        print("${x.value}  ")
        x = x.next
    }
    println()
}

