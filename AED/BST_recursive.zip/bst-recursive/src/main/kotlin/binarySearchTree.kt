data class Node<E>(var value: E, var left: Node<E>?, var right:Node<E>?)

fun <E> preorder(root: Node<E>?) {
    if (root != null) {
        print("${root.value.toString()} ")
        preorder(root.left)
        preorder(root.right)
    }
}

fun <E> inorder(root: Node<E>?) {
    if (root != null) {
        inorder(root.left)
        print("${root.value.toString()} ")
        inorder(root.right)
    }
}

fun <E> postorder(root: Node<E>?) {
    if (root != null) {
        preorder(root.left)
        preorder(root.right)
        print("${root.value.toString()} ")
    }
}

fun <E> minimum(root: Node<E>?): Node<E>? {
    return if (root!= null && root.left == null) root
    else root?.let { r -> minimum(r.left) }
}

fun <E> maximum(root: Node<E>?): Node<E>? {
    return if (root != null && root.right == null) root
    else root?.let { r -> maximum(r.right) }
}

fun <E> search(root: Node<E>?, key: E, cmp: Comparator<E>): Node<E>? {
    return if (root == null || cmp.compare(key, root.value) == 0) root
        else if (cmp.compare(key, root.value) < 0) search(root.left, key, cmp)
        else search(root.right, key, cmp)
}

fun <E> add(root: Node<E>?, e: E, cmp: Comparator<E>): Node<E>? {
    var root = root
    if (root == null) // not found, insert
        root = Node(e, null, null)
    else if (cmp.compare(e, root.value) <= 0) root.left = add(root.left, e, cmp)
    else root.right = add(root.right, e, cmp)
    return root
}

fun <E> remove(root: Node<E>?, e: E, cmp: Comparator<E>): Node<E>? {
    var root = root
    if (root == null) return root
    else if (cmp.compare(e, root.value) < 0) root.left = remove(root.left, e, cmp)
    else if (cmp.compare(e, root.value) > 0) root.right = remove(root.right, e, cmp)
    else { // found, delete it
        if (root.left == null) root = root.right
        else if (root.right == null) root = root.left
        else {
            val y = minimum(root.right)
            if (y != null) {
                root.value = y.value
                root.right = remove(root.right, y.value, cmp)
            }
        }
    }
    return root
}

