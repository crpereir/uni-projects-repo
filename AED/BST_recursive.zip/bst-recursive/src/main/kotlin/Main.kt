
fun main() {
    val cmp: (Int, Int) -> Int = { i1: Int, i2: Int -> i1 - i2 }

    var tree = createBST(cmp)
    print("Inorder: "); inorder(tree); println()
    println("Delete: " + 4); tree = remove(tree, 4, cmp)
    print("Inorder: "); inorder(tree); println()
}

fun createBST(cmp: Comparator<Int>): Node<Int>? {
    var tree: Node<Int>? = null
    tree = add(tree, 9, cmp)
    tree = add(tree, 4, cmp)
    tree = add(tree, 1, cmp)
    tree = add(tree, 8, cmp)
    tree = add(tree, 5, cmp)
    tree = add(tree, 6, cmp)
    tree = add(tree, 7, cmp)
    tree = add(tree, 0, cmp)
    tree = add(tree, 2, cmp)
    tree = add(tree, 3, cmp)
    return tree
}
